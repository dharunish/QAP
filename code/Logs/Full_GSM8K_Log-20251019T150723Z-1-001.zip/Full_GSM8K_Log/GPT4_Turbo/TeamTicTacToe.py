import sys

sys.stdin = open("tttt.in", "r")
sys.stdout = open("tttt.out", "w")


board = []

for i in range(3):
  board.append([*input()])
ones = set()
teams = set()

for row in board:
  setRow = set(row)
  if len(setRow) == 2:
    setRow = sorted(setRow)
    teams.add(f'{setRow[0]}{setRow[1]}')
  elif len(setRow) == 1:
    ones.add(f'{setRow}')

for i in range(3):
  column = set([board[0][i], board[1][i], board[2][i]])
  if len(column) == 2:
    column = sorted(column)
    teams.add(f'{column[0]}{column[1]}')
  elif len(column) == 1:
    ones.add(f'{column}')

diag1 = set()
for i in range(3):
  diag1.add(board[i][i])
if len(diag1) == 2:
  diag1 = sorted(diag1)
  teams.add(f'{diag1[0]}{diag1[1]}')
elif len(diag1) == 1:
  ones.add(f'{diag1}')

diag1 = set()
for i in range(3):
  diag1.add(board[i][-(i+1)])
if len(diag1) == 2:
  diag1 = sorted(diag1)
  teams.add(f'{diag1[0]}{diag1[1]}')
elif len(diag1) == 1:
  ones.add(f'{diag1}')


print(len(ones))
print(len(teams))



  




# for i, column in enumerate(board[0]):

#   previous = []
#   for z in range(3):
#     if board[z][i] not in previous:
  
#       previous.append(board[z][i])
#   if len(previous) == 2:
#     teams += 1
#   elif len(previous) == 1:
#     ones += 1
#   previous = []
#   count = 0


# for i in range(3):
#   if board[i][i] not in previous:
  
#     previous.append(board[i][i])
# if len(previous) == 2:
#   teams += 1
# elif len(previous) == 1:
#   ones += 1
# previous = []
# count = 0

# for i in range(3):
#   if board[i][-(i+1)] not in previous:

#     previous.append(board[i][-(i+1)])
# if len(previous) == 2:
#   teams += 1
# elif len(previous) == 1:
#   ones += 1
# previous = []
# count = 0

    
# print(ones)
# print(teams)


